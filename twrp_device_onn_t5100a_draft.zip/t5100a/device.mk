LOCAL_PATH := device/onn/t5100a

# A/B + virtual A/B-style boot control (MTK implementation copied from stock ramdisk)
AB_OTA_UPDATER := true
AB_OTA_PARTITIONS += boot system vendor product vbmeta vbmeta_system vbmeta_vendor

# Dynamic partitions
PRODUCT_USE_DYNAMIC_PARTITIONS := true
PRODUCT_VIRTUAL_AB_OTA := true   # lpdump header flag: virtual_ab_device

PRODUCT_PACKAGES += \
    update_engine \
    update_engine_sideload \
    update_verifier

# Stock MTK blobs needed for A/B slot handling in recovery (extracted from stock boot ramdisk)
PRODUCT_COPY_FILES += \
    $(LOCAL_PATH)/recovery/root/system/bin/mtk_plpath_utils:$(TARGET_COPY_OUT_RECOVERY)/root/system/bin/mtk_plpath_utils \
    $(LOCAL_PATH)/recovery/root/system/lib64/libmtk_bsg.so:$(TARGET_COPY_OUT_RECOVERY)/root/system/lib64/libmtk_bsg.so \
    $(LOCAL_PATH)/recovery/root/system/lib64/hw/android.hardware.boot@1.0-impl-1.2-mtkimpl.so:$(TARGET_COPY_OUT_RECOVERY)/root/system/lib64/hw/android.hardware.boot@1.0-impl-1.2-mtkimpl.so \
    $(LOCAL_PATH)/recovery/root/system/etc/init/mtk-plpath-utils.rc:$(TARGET_COPY_OUT_RECOVERY)/root/system/etc/init/mtk-plpath-utils.rc \
    $(LOCAL_PATH)/recovery/root/init.recovery.mt6765.rc:$(TARGET_COPY_OUT_RECOVERY)/root/init.recovery.mt6765.rc
