# Inherit from those products. Most specific first.
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/base.mk)

# TWRP common
$(call inherit-product, vendor/twrp/config/common.mk)

# Device
$(call inherit-product, device/onn/t5100a/device.mk)

PRODUCT_DEVICE := t5100a
PRODUCT_NAME := twrp_t5100a
PRODUCT_BRAND := onn
PRODUCT_MODEL := 100110603
PRODUCT_MANUFACTURER := onn
