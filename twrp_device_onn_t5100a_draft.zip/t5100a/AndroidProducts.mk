PRODUCT_MAKEFILES := $(LOCAL_DIR)/twrp_t5100a.mk
COMMON_LUNCH_CHOICES := \
    twrp_t5100a-eng \
    twrp_t5100a-userdebug \
    twrp_t5100a-user
