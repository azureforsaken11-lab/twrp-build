DEVICE_PATH := device/onn/t5100a

ALLOW_MISSING_DEPENDENCIES := true
BUILD_BROKEN_DUP_RULES := true
BUILD_BROKEN_ELF_PREBUILT_PRODUCT_COPY_FILES := true

# Architecture (recovery userland is 64-bit only)
TARGET_ARCH := arm64
TARGET_ARCH_VARIANT := armv8-a
TARGET_CPU_ABI := arm64-v8a
TARGET_CPU_ABI2 :=
TARGET_CPU_VARIANT := generic
TARGET_CPU_VARIANT_RUNTIME := cortex-a53
TARGET_2ND_ARCH := arm
TARGET_2ND_ARCH_VARIANT := armv8-a
TARGET_2ND_CPU_ABI := armeabi-v7a
TARGET_2ND_CPU_ABI2 := armeabi
TARGET_2ND_CPU_VARIANT := generic
TARGET_2ND_CPU_VARIANT_RUNTIME := cortex-a53

# Platform (from androidboot.hardware / DTB: MT6765 family; marketed as MT8768WA)
TARGET_BOARD_PLATFORM := mt6765
TARGET_BOOTLOADER_BOARD_NAME := t5100a
TARGET_NO_BOOTLOADER := true
TARGET_OTA_ASSERT_DEVICE := t5100a,100110603

# Boot image: header v2, kernel 4.19.191 (values read from the stock boot_a.img header)
BOARD_BOOT_HEADER_VERSION := 2
BOARD_KERNEL_BASE := 0x40078000
BOARD_KERNEL_PAGESIZE := 2048
BOARD_KERNEL_OFFSET := 0x00008000
BOARD_RAMDISK_OFFSET := 0x11a88000
BOARD_KERNEL_TAGS_OFFSET := 0x07808000
BOARD_DTB_OFFSET := 0x07808000
BOARD_KERNEL_CMDLINE := bootopt=64S3,32N2,64N2 buildvariant=user
BOARD_KERNEL_IMAGE_NAME := Image.gz
TARGET_PREBUILT_KERNEL := $(DEVICE_PATH)/prebuilt/Image.gz
TARGET_PREBUILT_DTB := $(DEVICE_PATH)/prebuilt/dtb.img
BOARD_INCLUDE_DTB_IN_BOOTIMG := true
BOARD_MKBOOTIMG_ARGS += --header_version $(BOARD_BOOT_HEADER_VERSION)
BOARD_MKBOOTIMG_ARGS += --ramdisk_offset $(BOARD_RAMDISK_OFFSET)
BOARD_MKBOOTIMG_ARGS += --tags_offset $(BOARD_KERNEL_TAGS_OFFSET)
BOARD_MKBOOTIMG_ARGS += --dtb $(TARGET_PREBUILT_DTB) --dtb_offset $(BOARD_DTB_OFFSET)
BOARD_MKBOOTIMG_ARGS += --os_version 12.0.0 --os_patch_level 2025-06

# Recovery lives in the boot partition (no recovery / vendor_boot partition in use)
BOARD_USES_RECOVERY_AS_BOOT := true
TARGET_NO_RECOVERY := true
BOARD_BOOTIMAGE_PARTITION_SIZE := 33554432

# A/B
AB_OTA_UPDATER := true

# Dynamic partitions (values from `lpdump` on the tablet: Virtual A/B, group main_a)
# super = 5028970496 bytes; group max = 5026873344 (super minus 2 MiB metadata)
BOARD_SUPER_PARTITION_SIZE := 5028970496
BOARD_SUPER_PARTITION_GROUPS := main
BOARD_MAIN_SIZE := 5026873344
BOARD_MAIN_PARTITION_LIST := system vendor product
BOARD_SYSTEMIMAGE_FILE_SYSTEM_TYPE := ext4
BOARD_VENDORIMAGE_FILE_SYSTEM_TYPE := ext4
BOARD_PRODUCTIMAGE_FILE_SYSTEM_TYPE := ext4

# File systems
BOARD_HAS_LARGE_FILESYSTEM := true
TARGET_USERIMAGES_USE_EXT4 := true
TARGET_USERIMAGES_USE_F2FS := true
TARGET_COPY_OUT_VENDOR := vendor
TARGET_COPY_OUT_PRODUCT := product
TARGET_RECOVERY_FSTAB := $(DEVICE_PATH)/recovery.fstab

# Verified boot
BOARD_AVB_ENABLE := true
BOARD_AVB_MAKE_VBMETA_IMAGE_ARGS += --flags 3

# TWRP
TW_THEME := landscape_hdpi
TW_ROTATION := 0                  # TODO try 90 if the UI comes up sideways
TARGET_RECOVERY_PIXEL_FORMAT := RGBX_8888
TW_USE_TOOLBOX := true
TW_USE_NEW_MINADBD := true
TW_EXTRA_LANGUAGES := true
TW_INCLUDE_NTFS_3G := true
RECOVERY_SDCARD_ON_DATA := true
BOARD_HAS_NO_SELECT_BUTTON := true
TW_NO_SCREEN_BLANK := true
TW_BRIGHTNESS_PATH := "/sys/class/leds/lcd-backlight/brightness"   # TODO verify
TW_MAX_BRIGHTNESS := 255                                           # TODO verify
TW_DEFAULT_BRIGHTNESS := 120
# First milestone: boot, touch, adb, flashing. /data uses FBE v2 + metadata encryption
# backed by Trustonic TEE keymaster, so decryption is a later step.
TW_INCLUDE_CRYPTO := false
TW_INCLUDE_FBE := false
