LOCAL_PATH := $(call my-dir)
ifneq ($(filter t5100a,$(TARGET_DEVICE)),)
include $(call all-makefiles-under,$(LOCAL_PATH))
endif
