# TWRP device tree (DRAFT) -- onn 10.4" Tablet Pro Gen 3 (t5100a, MT6765/MT8768WA)

Built from: stock-derived boot_a.img (header v2, kernel 4.19.191, Android 12 / SP1A.210812.016).
NOT compiled or tested. Open items marked TODO in BoardConfig.mk.

## Build
mkdir twrp && cd twrp
repo init -u https://github.com/minimal-manifest-twrp/platform_manifest_twrp_aosp.git -b twrp-12.1 --depth=1
repo sync -c -j8 --no-clone-bundle --no-tags
mkdir -p device/onn && cp -r <this folder> device/onn/t5100a
source build/envsetup.sh && lunch twrp_t5100a-eng && mka bootimage

## Test safely (never overwrite your only working boot slot first)
1. Back up boot_a / boot_b.
2. Write the TWRP image to the INACTIVE slot, switch to it, then switch back if it fails.
3. vbmeta may need flags 3 (disable verity+verification) to accept a modified boot.
